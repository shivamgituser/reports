package com.m2p.loyaltyreportservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoyaltyReportServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoyaltyReportServiceApplication.class, args);
	}

}
