package com.m2p.loyaltyreportservice.Repository;

import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ReportConfigEntityRepository extends JpaRepository<ReportConfigEntity, UUID> {

    @Query("select rce from ReportConfigEntity rce where rce.isSFTP = ?1")
    public Page<ReportConfigEntity> findAllByIsSFTP(Boolean isSFTP, Pageable pageable);
}
