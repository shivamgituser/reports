package com.m2p.loyaltyreportservice.azure;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;

@Service
@Slf4j
public class AzureBlobStorageService {
    @Value("${lyl.edw.azure_blob.url}")
    private String blobUrl;

    @Value("${lyl.edw.azure_blob.accountName}")
    private String blobAccountNumber;

    @Value("${lyl.edw.azure_blob.accountKey}")
    private String blobAccountKey;

    @Value("${lyl.edw.azure_blob.containerName}")
    private String blobContainerName;

    @Value("${lyl.edw.azure_blob.storage}")
    private String blobStorage;

    public void uploadFileToBlobStorage(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            BlobContainerClient container = new BlobContainerClientBuilder()
                    .endpoint(String.format(Locale.ROOT, blobUrl, blobAccountNumber))
                    .credential(new StorageSharedKeyCredential(blobAccountNumber, blobAccountKey))
                    .containerName(blobContainerName)
                    .buildClient();
            BlobClient blob = container.getBlobClient(blobStorage.concat(file.getName()));
            try {
                log.info("{} uploading started....",filePath);
                blob.upload(new FileInputStream(file), file.length(), true);
                log.info("{} uploaded successfully....",filePath);
            } catch (Exception e) {
                log.error("The file upload to Azure Blob failed" + e.getMessage());
            }
            log.info("Initiating to delete the file :: " + file.getName());
            Path fileLocation = Paths.get(filePath);
            try {
                Files.delete(fileLocation);
            } catch (IOException e) {
                log.error("File Deleted was not successful");
            }
            log.info("File was deleted successfully :: " + file.getName() + " :: status");
        }
    }
}
