package com.m2p.loyaltyreportservice.batch.config;


import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import com.m2p.loyaltyreportservice.batch.processor.ReportConfigEntityProcessor;
import com.m2p.loyaltyreportservice.batch.reader.ReportConfigEntityReader;
import com.m2p.loyaltyreportservice.batch.writer.ReportsConfigEntityWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
@EnableBatchProcessing
@Slf4j
public class ReportConfigEntityBatchConfig {

    @Autowired
    JobBuilderFactory jobBuilderFactory;
    @Autowired
    StepBuilderFactory stepBuilderFactory;
    @Autowired
    ReportConfigEntityProcessor reportConfigEntityProcessor;

    @Autowired
    ReportsConfigEntityWriter reportsConfigEntityWriter;

    @Autowired
    ReportConfigEntityReader reportConfigEntityReader;

    @Value(("${lyl.edw.chunk_size}"))
    private String chunkSize;


    @Bean
    public Job reportConfigEntityJob(Step reportConfigEntityJobStep1) {
        return jobBuilderFactory
                .get("reportConfigEntityJob")
                .incrementer(new RunIdIncrementer())
                .start(reportConfigEntityJobStep1)
                .build();
    }

    @Bean
    public Step reportConfigEntityJobStep1() throws java.text.ParseException {
        return stepBuilderFactory
                .get("reportConfigEntityJobStep1")
                .<ReportConfigEntity, ReportConfigEntity>chunk(Integer.valueOf(chunkSize))
                .reader(reportConfigEntityReader)
                .processor(reportConfigEntityProcessor)
                .writer(reportsConfigEntityWriter)
                .build();
    }
}
