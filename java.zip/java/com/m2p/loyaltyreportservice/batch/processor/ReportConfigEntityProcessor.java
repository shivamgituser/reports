package com.m2p.loyaltyreportservice.batch.processor;

import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ReportConfigEntityProcessor implements ItemProcessor<ReportConfigEntity,ReportConfigEntity> {
    @Override
    public ReportConfigEntity process(ReportConfigEntity item) throws Exception {
        log.info("Inside Processor");
        return item;
    }
}
