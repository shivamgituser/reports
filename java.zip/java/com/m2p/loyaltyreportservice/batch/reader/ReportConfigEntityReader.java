package com.m2p.loyaltyreportservice.batch.reader;

import com.m2p.loyaltyreportservice.Repository.ReportConfigEntityRepository;
import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Component
@Slf4j
public class ReportConfigEntityReader extends RepositoryItemReader<ReportConfigEntity>  {

    @Autowired
    ReportConfigEntityRepository reportConfigEntityRepository;

    @PostConstruct
    protected void init() {
        this.setRepository(reportConfigEntityRepository);
        this.setMethodName("findAllByIsSFTP");
        this.setPageSize(50);
        final List<Boolean> arguments = new ArrayList<>();
        arguments.add(Boolean.TRUE);
        this.setArguments(arguments);
        final HashMap<String, Sort.Direction> sorts = new HashMap<>();
        sorts.put("createdDate", Sort.Direction.ASC);
        this.setSort(sorts);
    }

}
