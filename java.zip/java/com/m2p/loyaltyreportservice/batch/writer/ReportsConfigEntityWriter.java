package com.m2p.loyaltyreportservice.batch.writer;

import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import com.m2p.loyaltyreportservice.service.ReportsGeneratorService;
import com.m2p.loyaltyreportservice.utitlity.DateUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.List;

@Component
@Slf4j
public class ReportsConfigEntityWriter implements ItemWriter<ReportConfigEntity> , StepExecutionListener {

    @Qualifier("SFTPReportsGeneratorService")
    @Autowired
    ReportsGeneratorService reportsGeneratorService;

    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String sorting;

    @Override
    public void write(List<? extends ReportConfigEntity> items) throws Exception {
        for(ReportConfigEntity reportConfigEntity:items) {
            reportsGeneratorService.generateReport(reportConfigEntity,startDate,endDate,sorting);
        }

    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        try {
            startDate= DateUtility.converDateStringtoStartDate((String) stepExecution.getJobParameters().getString("startDate"));
            endDate=DateUtility.converDateStringtoEndDate((String) stepExecution.getJobParameters().getString("endDate"));
            sorting=(String) stepExecution.getJobParameters().getString("sorting");
            log.info("startDate.....{}",startDate.toString());
            log.info("endDate...{}",endDate.toString());
            log.info("sorting...{}",sorting);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return null;
    }
}
