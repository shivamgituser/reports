package com.m2p.loyaltyreportservice.constant;

public class SystemsConstant {
    public static final String REPORT_FORMAT_MAPPER_PACKAGE_NAME="com.m2p.loyaltyreportservice.rowmapper.";
    public static final String REPORT_FORMAT_PACKAGE_NAME="com.m2p.loyaltyreportservice.reportformat.";
}
