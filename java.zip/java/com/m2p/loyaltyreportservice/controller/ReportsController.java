package com.m2p.loyaltyreportservice.controller;

import com.m2p.loyaltyreportservice.utitlity.DateUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/v1")
@EnableAutoConfiguration
@EnableScheduling
@Slf4j
public class ReportsController {


    @Autowired
    private JobLauncher jobLauncher;



    @Autowired
    @Qualifier("reportConfigEntityJob")
    private Job reportConfigEntityJob;

    @GetMapping(path = "/reports")
    @Scheduled(cron="59 59 23 * * *")
    public ResponseEntity<String> saveReportToSFTP() {
        JobParameters Parameters = new JobParametersBuilder()
                .addString("endDate",DateUtility.getCurrentDate().toString())
                .addString("sorting","ASC")
                .addString("startDate", DateUtility.getCurrentDate().toString())
                .addLong("startAt", System.currentTimeMillis()).toJobParameters();
        try {
            jobLauncher.run(reportConfigEntityJob, Parameters);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException |
                 JobParametersInvalidException e) {

            e.printStackTrace();
        }
        return new ResponseEntity<>("Batch Process started!!", HttpStatus.OK);
    }

    @GetMapping(path= "/reports/{startDate}/{endDate}/{sorting}")
    public ResponseEntity<String> saveReportToSFTP(@PathVariable String startDate, @PathVariable String endDate,@PathVariable String sorting) {
        log.info("Inside date range controller....");
        JobParameters Parameters = new JobParametersBuilder()
                .addString("endDate",endDate)
                .addString("sorting",sorting.toUpperCase())
                .addString("startDate", startDate)
                .addLong("startAt", System.currentTimeMillis()).toJobParameters();
        try {
            jobLauncher.run(reportConfigEntityJob, Parameters);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException |
                 JobParametersInvalidException e) {

            e.printStackTrace();
        }
        return new ResponseEntity<>("Batch Process started!!", HttpStatus.OK);
    }


}
