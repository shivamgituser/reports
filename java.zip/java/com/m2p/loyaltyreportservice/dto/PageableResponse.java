package com.m2p.loyaltyreportservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class PageableResponse {

    @JsonProperty("page_no")
    private Integer pageNo;

    @JsonProperty("page_size")
    private Integer pageSize;


    @JsonProperty("total_pages")
    private Integer totalPages;

    @JsonProperty("total_elements")
    private Long totalElements;

    @JsonProperty("is_last")
    private Boolean isLast;

    @JsonProperty("is_first")
    private Boolean isFirst;

    @Override
    public String toString() {
        return "PageableResponse{" +
                "pageNo=" + pageNo +
                ", pageSize=" + pageSize +
                ", totalPages=" + totalPages +
                ", totalElements=" + totalElements +
                ", isLast=" + isLast +
                ", isFirst=" + isFirst +
                '}';
    }
}
