package com.m2p.loyaltyreportservice.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
    @Setter
    public class Response {
        @JsonProperty("code")
        protected String code;

    /*
*
         * Response status `success` or `error*/


        public enum StatusEnum {
            SUCCESS("success"), FAILURE("failure"), ERROR("error");

            private final String value;

            StatusEnum(String value) {
                this.value = value;
            }

            @Override
            @JsonValue
            public String toString() {
                return String.valueOf(value);
            }

            @JsonCreator
            public static StatusEnum fromValue(String text) {
                for (StatusEnum b : StatusEnum.values()) {
                    if (String.valueOf(b.value).equals(text)) {
                        return b;
                    }
                }
                return null;
            }
        }

        @JsonProperty("status")
        private StatusEnum status;



        @JsonProperty("message")
        private String message;

        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
        private LocalDateTime timestamp;

        @JsonProperty("description")
        private String description;

        @JsonProperty("data")
        private Object data = null;

        @JsonProperty("pageable_response")
        private PageableResponse  pageableResponse;

        public Response code(String code) {
            this.code = code;
            return this;
        }


    public Response(String code, StatusEnum status, String message, String description, Object data) {
        this.code = code;
        this.status = status;
        this.message = message;
        this.timestamp =  LocalDateTime.now();
        this.description = description;
        this.data = data;
    }


    public Response(Object data, PageableResponse pageableResponse){
        this.data =data;
        this.pageableResponse=pageableResponse;
    }
    public Response(String code, StatusEnum status, String message, String description, Response response) {
        this.code = code;
        this.status = status;
        this.message = message;
        this.timestamp =  LocalDateTime.now();
        this.description = description;
        this.data = response.getData();
        this.pageableResponse = response.getPageableResponse();
    }

    public Response(String code, StatusEnum status, String message, String description) {
            super();
            this.code = code;
            this.status = status;
            this.message = message;
            this.description = description;
            this.timestamp =  LocalDateTime.now();
        }

        public Response(String code, StatusEnum status, String message, Object data) {
            super();
            this.code = code;
            this.status = status;
            this.message = message;
            this.data = data;
            this.timestamp =  LocalDateTime.now();

        }
    public Response(String code, StatusEnum status, String message, LocalDateTime timestamp, String description, Object data, PageableResponse pageableResponse) {
        this.code = code;
        this.status = status;
        this.message = message;
        this.timestamp =  LocalDateTime.now();
        this.description = description;
        this.data = data;
        this.pageableResponse = pageableResponse;
    }

        public Response() {

        }
}
