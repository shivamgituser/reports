package com.m2p.loyaltyreportservice.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.EntityListeners;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import java.time.LocalDateTime;

@Getter
@Setter
@MappedSuperclass
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@EntityListeners(AuditingEntityListener.class)
public abstract class Auditable<U> {


    protected U createdBy;

    protected LocalDateTime createdDate;

    protected U lastModifiedBy;

    protected LocalDateTime lastModifiedDate;


    protected Boolean isDelete;

    protected String status;

}