package com.m2p.loyaltyreportservice.entity;


import lombok.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Getter
@Setter
@EntityListeners(AuditingEntityListener.class)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Inheritance(strategy= InheritanceType.TABLE_PER_CLASS)
@Table(name = "reports_config")
public class ReportConfigEntity extends Auditable<UUID> {
    @Id
    @Column(name = "report_config_id", updatable = false, nullable = false)
    private UUID reportConfigId;

    @Column(name = "report_name",unique = true)
    public String reportName;

    @Column(name = "query")
    public String query;

    @Column(name = "format")
    public String format;

    @Column(name = "is_sftp")
    public Boolean isSFTP;

    @Column(name = "is_mail")
    public Boolean isMail;

    @Column(name= "is_downloadable")
    public Boolean isDownloadable;

}
