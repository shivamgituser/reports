package com.m2p.loyaltyreportservice.filegenerator;

import com.m2p.loyaltyreportservice.utitlity.FileUtility;
import com.opencsv.CSVWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service("CsvFileGeneratorServiceImpl")
@Slf4j
public class CsvFileGeneratorServiceImpl implements FileGeneratorService {

    @Autowired
    FileUtility fileUtility;
    @Override
    public <T> void generateFile(List<T> dataList, String reportName,Class<?> dataType) {
        String filePath=fileUtility.getFileName(reportName);
//        if (dataList == null || dataList.isEmpty()) {
//            log.info("Data list is empty. CSV file will not be generated.");
//            return;
//        }

        log.info("Entering file generator service:::");
        File file = new File(filePath);
        boolean isFileExists = new File(filePath).exists();

        try (FileWriter fileWriter = new FileWriter(filePath, true);
             CSVWriter csvWriter = new CSVWriter(fileWriter)) {

            // Define the CSV header
            if (!file.exists() || file.length() == 0) {
                String[] header = getHeaders(dataType);
                csvWriter.writeNext(header);
            }

            //populate csv file
            for (T data : dataList) {
                String[] rowData = getRowData(data);
                if(!isRowDataEmpty(rowData)) {
                    csvWriter.writeNext(rowData);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            log.error("errror!!!!");
            System.err.println("Error creating CSV file: " + e.getMessage());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }


    }

    public  String[] getHeaders(Class<?> dataType) {
        Field[] fields = dataType.getDeclaredFields();
        String headers[] = new String[fields.length];
        int index = 0;
        for (Field field : fields) {
            field.setAccessible(true);
            headers[index++] = field.getName();
        }

        return headers;
    }

    public <T> String[] getRowData(T entity) throws IllegalAccessException {
        Field[] fields = entity.getClass().getDeclaredFields();
        String[] rowData = new String[fields.length];
        int index = 0;
        for (Field field : fields) {
            field.setAccessible(true);
            Object value = field.get(entity);
            if (value != null) {
                if (value instanceof String) {
                    rowData[index] = ((String) value);
                } else if (value instanceof Integer) {
                    rowData[index] = String.valueOf(value);
                } else if (value instanceof Double) {
                    rowData[index] = (String.valueOf(value));
                } else if (value instanceof Boolean) {
                    rowData[index] = (String.valueOf(value));
                } else if (value instanceof UUID) {
                    rowData[index] = value.toString();
                } else if (value instanceof LocalDateTime) {
                    rowData[index] = String.valueOf(value);
                } else if(value instanceof Date){
                    rowData[index] = String.valueOf(value);
                }
            }
            index++;
        }
        return rowData;
    }

    public Boolean isRowDataEmpty(String[] rowData){
        for(String row:rowData){
            if( row != null && row.trim().length() > 0){
                return false;
            }
        }
        return true;
    }
}
