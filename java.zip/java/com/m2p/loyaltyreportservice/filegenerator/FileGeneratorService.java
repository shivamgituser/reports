package com.m2p.loyaltyreportservice.filegenerator;

import java.util.List;

public interface FileGeneratorService {
    public  <T> void generateFile(List<T> dataList, String filePath,Class<?> dataType);
}
