package com.m2p.loyaltyreportservice.reportformat;

import lombok.*;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class UpsFormat {
    public LocalDateTime txnDate;
    public String corporateName;
    public String entityID;
    public String exTxnID;
    public Double amount;
    public String transactionSubType;
    public String status;
    public Double postWalletBalance;
    public String type;
    public Double txnAmount;
    public String description;
}
