package com.m2p.loyaltyreportservice.rowmapper;

import com.m2p.loyaltyreportservice.reportformat.UpsFormat;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

@Component
public class UpsFormatMapper implements RowMapper<UpsFormat> {
    @Override
    public UpsFormat mapRow(ResultSet rs, int rowNum) throws SQLException {
        UpsFormat ups_format=new UpsFormat();
        ups_format.setEntityID(rs.getString("entity_id"));
        ups_format.setCorporateName(rs.getString("channel_name"));
        ups_format.setStatus(rs.getString("status"));
        ups_format.setAmount(rs.getDouble("amount"));
        ups_format.setType(rs.getString("type"));
        ups_format.setExTxnID(rs.getString("ex_txn_id"));
        ups_format.setTxnAmount(rs.getDouble("amount"));
        ups_format.setTxnDate(rs.getObject("created_date", LocalDateTime.class));
        ups_format.setTransactionSubType(rs.getString("sub_type"));
        ups_format.setPostWalletBalance(rs.getDouble("wallet_balance"));
        ups_format.setDescription(rs.getString("reason"));

        return ups_format;
    }
}
