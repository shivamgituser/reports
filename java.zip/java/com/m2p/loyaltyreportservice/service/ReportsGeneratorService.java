package com.m2p.loyaltyreportservice.service;

import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import java.time.LocalDateTime;

public interface ReportsGeneratorService {
    public void generateReport(ReportConfigEntity reportConfigEntity, LocalDateTime startDate,LocalDateTime endDate,String sorting);
}
