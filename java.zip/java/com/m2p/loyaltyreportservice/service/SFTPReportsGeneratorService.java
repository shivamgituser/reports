package com.m2p.loyaltyreportservice.service;

import com.m2p.loyaltyreportservice.azure.AzureBlobStorageService;
import com.m2p.loyaltyreportservice.constant.SystemsConstant;
import com.m2p.loyaltyreportservice.entity.ReportConfigEntity;
import com.m2p.loyaltyreportservice.rowmapper.UpsFormatMapper;
import com.m2p.loyaltyreportservice.filegenerator.FileGeneratorService;
import com.m2p.loyaltyreportservice.utitlity.FileUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import java.lang.reflect.Constructor;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Data
@Slf4j
public class SFTPReportsGeneratorService implements ReportsGeneratorService{

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    FileUtility fileUtility;

    @Autowired
    UpsFormatMapper ups_formatMapper;

    @Qualifier("CsvFileGeneratorServiceImpl")
    @Autowired
    FileGeneratorService fileGeneratorService;

    @Autowired
    AzureBlobStorageService azureBlobStorageService;

    @Override
    public void  generateReport(ReportConfigEntity reportConfigEntity, LocalDateTime startDate, LocalDateTime endDate, String sorting) {
        try {

            int pageSize = 100;
            int page = 0;

            String fileName = fileUtility.getFileName(reportConfigEntity.getReportName());
            String reportFormatMapperFullyQualifiedClassName = SystemsConstant.REPORT_FORMAT_MAPPER_PACKAGE_NAME + reportConfigEntity.getFormat() + "Mapper";
            log.info("reportFormatMapperFullyQualifiedClassName::::::{}", reportFormatMapperFullyQualifiedClassName);
            Class<?> dynamicClass = Class.forName(reportFormatMapperFullyQualifiedClassName);
            Constructor<?> constructor = dynamicClass.getDeclaredConstructor();
            RowMapper<?> rowMapper = (RowMapper<?>) constructor.newInstance();

            Class<?> reportFormatDynamicClass=Class.forName(SystemsConstant.REPORT_FORMAT_PACKAGE_NAME+reportConfigEntity.getFormat());

            String query = reportConfigEntity.getQuery();
            log.info("query is:::::{}", query);
            fileUtility.clearFileIfExists(fileName);

            List<?> dataList;
            do {
                dataList = jdbcTemplate.query(query, new Object[]{startDate, endDate, pageSize, page * pageSize}, rowMapper);
                fileGeneratorService.generateFile(dataList, reportConfigEntity.getReportName(),reportFormatDynamicClass);
                page++;
            } while (!dataList.isEmpty());

            /* upload generated file to azure */
            azureBlobStorageService.uploadFileToBlobStorage(fileName);

        }catch(ClassNotFoundException classNotFoundException){
            log.info("ClassNotFoundException occurred:::{}", classNotFoundException.getMessage());
        }catch(DataAccessException dataAccessException){
            log.info("DataAccessException occurred:::Sql Query is Wrong{}",dataAccessException.getMessage());
        }
        catch(Exception e){
            log.info("Exception Occurred:::{}",e.getMessage());
        }
    }
}
