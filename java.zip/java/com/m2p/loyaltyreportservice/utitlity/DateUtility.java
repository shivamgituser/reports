package com.m2p.loyaltyreportservice.utitlity;

import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;

import static java.time.temporal.TemporalAdjusters.firstDayOfYear;
import static java.time.temporal.TemporalAdjusters.lastDayOfYear;

@Slf4j
public class DateUtility {

    private final static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

    private final static String START_OF_DAY = "00:00:00.000";

    private final static String END_OF_DAY = "23:59:59.000";



    public static LocalDate getCurrentDate(){
        LocalDate localDate = LocalDate.now();
        return localDate;
   }

    public static LocalDateTime getCurrentDateTime(){
        LocalDateTime localDateTime = LocalDateTime.now();
        return localDateTime;
    }

    public static LocalDateTime converDateStringtoDate(String dateInString) throws ParseException {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        LocalDateTime date = LocalDateTime.parse(dateInString, formatter);
        return date;
    }
    public static LocalDateTime converDateStringtoStartDate(String dateInString) throws ParseException {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        LocalDateTime date = LocalDateTime.parse(dateInString+" "+START_OF_DAY, formatter);
        log.info("start date:::"+date.toString());
        return date;
    }

    public static LocalDateTime converDateStringtoEndDate(String dateInString) throws ParseException {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        LocalDateTime date = LocalDateTime.parse(dateInString+" "+END_OF_DAY, formatter);
        log.info("end date:::"+date.toString());

        return date;
    }


    public static LocalDateTime getAfterDateByYearly(Integer duration) {

        LocalDate date =  LocalDate.now();
        LocalDate expiredDate = date.plusYears(duration);

        return  LocalDateTime.of(expiredDate,LocalTime.MAX);
    }

    public static LocalDateTime getAfterDateBymonthly(
            Integer duration) {
        LocalDate date =  LocalDate.now();
        LocalDate expiredDate = date.plusMonths(duration);

       return  LocalDateTime.of(expiredDate,LocalTime.MAX);
    }

    public static LocalDateTime getAfterDateByWeekly(Integer duration) {
        LocalDate date =  LocalDate.now();
        LocalDate expiredDate = date.plusWeeks(duration);

        return  LocalDateTime.of(expiredDate,LocalTime.MAX);
    }

    public static LocalDateTime getafterdatebydaily(Integer duration) {

        LocalDate date =  LocalDate.now();
        LocalDate expiredDate = date.plusMonths(6);

        return  LocalDateTime.of(expiredDate,LocalTime.MAX);
    }
        /* need to refactor it has to be moved to points Accrual */



    public static LocalDateTime getCurrentYearFirstDay() {
        LocalDateTime now = LocalDateTime.now();

        LocalDateTime lastDay = now.with(firstDayOfYear()); // 2015-12-31

        return lastDay;
    }

    public static LocalDateTime getCurrentYearLastDay() {
        LocalDateTime now = LocalDateTime.now();

        LocalDateTime firstDay = now.with(lastDayOfYear()); // 2015-01-01

        return firstDay;
    }

    public static LocalDateTime getFirstDateOfHalfYearly() {
        LocalDateTime today = LocalDateTime.now();
        Calendar calendar = Calendar.getInstance();

        return today.withDayOfMonth(calendar.getActualMinimum(Calendar.DAY_OF_MONTH));

    }
    public static LocalDateTime getLastDateOfHalfYearly() {
        LocalDateTime today = LocalDateTime.now();
        Calendar calendar = Calendar.getInstance();

        return today.withDayOfMonth(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

    }

    public static LocalDate getFirstDateOfCurrentQuarter() {
        LocalDate localDate = LocalDate.now();
        LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter())
                .with(TemporalAdjusters.firstDayOfMonth());
        return firstDayOfQuarter;

    }
    public static LocalDate getLastDateOfCurrentQuarter() {
        LocalDate localDate = LocalDate.now();
        LocalDate firstDayOfQuarter = getFirstDateOfCurrentQuarter();

        LocalDate lastDayOfQuarter = firstDayOfQuarter.plusMonths(2)
                .with(TemporalAdjusters.lastDayOfMonth());
        return lastDayOfQuarter;

    }

    public static LocalDateTime getFirstDateOfMonth() {

        LocalDateTime today = LocalDateTime.now();
        Calendar calendar = Calendar.getInstance();

        return today.withDayOfMonth(calendar.getActualMinimum(Calendar.DAY_OF_MONTH));

    }

    public static LocalDateTime getLastDateOfMonth() {
        LocalDateTime today = LocalDateTime.now();
        Calendar calendar = Calendar.getInstance();

        return today.withDayOfMonth(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

    }

    public static String getMonth() {
        LocalDateTime today = LocalDateTime.now();
        return String.valueOf(today.getMonth().getValue());
    }

    public static String getYear() {
        LocalDateTime today = LocalDateTime.now();
        return String.valueOf(today.getYear());
    }

    public static LocalDate converDateStringtoDateFormat(String dateInString) throws ParseException {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        LocalDate date = LocalDate.parse(dateInString, formatter);
        return date;
    }


    public static String getDay() {
        LocalDateTime today = LocalDateTime.now();
        return String.valueOf(today.getDayOfMonth());
    }
}
