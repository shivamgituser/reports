package com.m2p.loyaltyreportservice.utitlity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
@Data
@Getter
@Setter
@Slf4j
public class FileUtility {

    @Value("${lyl.edw.base.path}")
    private  String filePath;

    public  void clearFileIfExists(String CSV_FILE) {
        File file = new File(CSV_FILE);
        if (file.exists()) {
            if (file.delete()) {
                System.out.println(CSV_FILE+"::::cleared!");
                System.out.println("CSV file cleared for the new job execution.");
            } else {
                System.err.println("Failed to clear CSV file for the new job execution.");
            }
        }
    }

    public  String getDateString(){
        log.info("file generating at:::{}",DateUtility.getCurrentDateTime());
        LocalDate todayDate=DateUtility.getCurrentDate();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String formattedDate=todayDate.format(formatter);
        log.info("formattedDate is:{}",formattedDate);
        return formattedDate;
    }


    public String getFileName(String entity){

        return filePath+entity+getDateString()+".csv";
    }
}
